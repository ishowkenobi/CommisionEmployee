import java.util.ArrayList;
import java.util.Scanner;

public class EmployeeManagementSystem {

    // ArrayList to store employees
    private static ArrayList<BasePlusCommissionEmployee> employees = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    // Method to add a new employee
    private static void addEmployee() {
        System.out.println("Enter the employee's first name:");
        String firstName = scanner.nextLine();

        System.out.println("Enter the employee's last name:");
        String lastName = scanner.nextLine();

        System.out.println("Enter the employee's SSN:");
        String ssn = scanner.nextLine();

        System.out.println("Enter the employee's gross sales:");
        double grossSales = scanner.nextDouble();

        System.out.println("Enter the employee's commission rate (between 0 and 1):");
        double commissionRate = scanner.nextDouble();

        System.out.println("Enter the employee's base salary:");
        double baseSalary = scanner.nextDouble();
        scanner.nextLine();  // Consume the newline

        // Create a new employee and add to the list
        BasePlusCommissionEmployee newEmployee = new BasePlusCommissionEmployee(firstName, lastName, ssn, grossSales, commissionRate, baseSalary);
        employees.add(newEmployee);
        System.out.println("Employee added successfully!\n");
    }

    // Method to update an employee's base salary
    private static void updateBaseSalary() {
        System.out.println("Enter the employee's SSN to update their base salary:");
        String ssn = scanner.nextLine();

        // Find the employee by SSN
        for (BasePlusCommissionEmployee employee : employees) {
            if (employee.getSocialSecurityNumber().equals(ssn)) {
                System.out.println("Current base salary: " + employee.getBaseSalary());

                System.out.println("Enter the new base salary:");
                double newBaseSalary = scanner.nextDouble();
                employee.setBaseSalary(newBaseSalary);
                System.out.println("Base salary updated successfully!\n");
                return;
            }
        }

        System.out.println("Employee with SSN " + ssn + " not found!\n");
    }

    // Method to display an employee's information and earnings
    private static void displayEmployeeEarnings() {
        System.out.println("Enter the employee's SSN to view their earnings:");
        String ssn = scanner.nextLine();

        // Find the employee by SSN
        for (BasePlusCommissionEmployee employee : employees) {
            if (employee.getSocialSecurityNumber().equals(ssn)) {
                System.out.println(employee.toString());
                System.out.println("Earnings: " + employee.earnings() + "\n");
                return;
            }
        }

        System.out.println("Employee with SSN " + ssn + " not found!\n");
    }

    // Method to display the main menu
    private static void displayMenu() {
        System.out.println("------ Employee Management System ------");
        System.out.println("1. Add a new employee");
        System.out.println("2. Update employee's base salary");
        System.out.println("3. View employee earnings");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }

    // Main method to run the program
    public static void main(String[] args) {
        int choice;

        do {
            displayMenu();
            choice = scanner.nextInt();
            scanner.nextLine();  // Consume the newline

            switch (choice) {
                case 1:
                    addEmployee();
                    break;
                case 2:
                    updateBaseSalary();
                    break;
                case 3:
                    displayEmployeeEarnings();
                    break;
                case 4:
                    System.out.println("Exiting the system. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.\n");
            }
        } while (choice != 4);

        scanner.close();
    }
}
